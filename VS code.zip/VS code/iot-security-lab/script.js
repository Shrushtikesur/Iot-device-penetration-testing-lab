function startScan(){

document.getElementById("scanStatus").innerHTML =
"Scanning device... Vulnerabilities detected!";

}