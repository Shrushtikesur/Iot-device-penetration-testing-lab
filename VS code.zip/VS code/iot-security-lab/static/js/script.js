window.onload = function(){

let page = window.location.pathname;

if(page == "/") startMatrix();
if(page.includes("dashboard")) dashboardAnim();
if(page.includes("add_device")) linesAnim();
if(page.includes("discover")) radarAnim();
if(page.includes("scan_result")) scanAnim();

}

// MATRIX LOGIN
function startMatrix(){
const canvas=document.getElementById("matrix");
if(!canvas) return;

const ctx=canvas.getContext("2d");
canvas.height=window.innerHeight;
canvas.width=window.innerWidth;

const letters="01";
const fontSize=14;
const columns=canvas.width/fontSize;

const drops=[];
for(let i=0;i<columns;i++) drops[i]=1;

function draw(){
ctx.fillStyle="rgba(0,0,0,0.05)";
ctx.fillRect(0,0,canvas.width,canvas.height);

ctx.fillStyle="#00ff9c";
ctx.font=fontSize+"px monospace";

for(let i=0;i<drops.length;i++){
let text=letters[Math.floor(Math.random()*letters.length)];
ctx.fillText(text,i*fontSize,drops[i]*fontSize);

if(drops[i]*fontSize>canvas.height) drops[i]=0;
drops[i]++;
}
}
setInterval(draw,33);
}

// DASHBOARD GRID
function dashboardAnim(){
document.body.style.background =
"linear-gradient(#00ff9c22 1px, transparent 1px), linear-gradient(90deg,#00ff9c22 1px,transparent 1px)";
document.body.style.backgroundSize="40px 40px";
}

// ADD DEVICE
function linesAnim(){
document.body.style.background =
"repeating-linear-gradient(90deg,#00ff9c11,#00ff9c11 2px,black 2px,black 40px)";
}

// DISCOVER
function radarAnim(){
let size=0;
setInterval(()=>{
size+=5;
document.body.style.background =
`radial-gradient(circle,#00ff9c22 ${size}px,black ${size+5}px)`;
},100);
}

// RESULT
function scanAnim(){
let pos=0;
setInterval(()=>{
pos+=5;
document.body.style.background =
`linear-gradient(transparent,#00ff9c33,transparent)`;
},50);
}

// LOAD DEVICES
function loadDevices(){

fetch("/api/devices")
.then(res => res.json())
.then(data => {

console.log("Devices:", data); // debug

let table = document.getElementById("deviceTable");

if(!table){
console.log("Table not found");
return;
}

table.innerHTML = "";

data.devices.forEach(d => {

table.innerHTML += `
<tr>
<td>${d[0]}</td>
<td>${d[1]}</td>
<td>${d[2]}</td>
<td>${d[3]}</td>
<td><a href="/scan/${d[2]}" class="btn">Scan</a></td>
</tr>
`;

});

});
}

// SCAN ANIMATION
function startScan(ip){
let t=document.getElementById("terminal");

let lines=[
"Initializing...",
"Connecting...",
"Scanning...",
"Analyzing...",
"Done"
];

let i=0;

function run(){
if(i<lines.length){
t.innerHTML+=lines[i]+"<br>";
i++;
setTimeout(run,700);
}else{
setTimeout(()=>{window.location="/scan_result/"+ip;},1000);
}
}
run();
}
document.addEventListener("DOMContentLoaded", () => {
    loadDevices();
});

function loadDevices(){

fetch("/api/devices")
.then(res => res.json())
.then(data => {

let table = document.getElementById("deviceTable");
let total = document.getElementById("totalDevices");

if(total) total.innerText = data.devices.length;

table.innerHTML = "";

data.devices.forEach(d => {

table.innerHTML += `
<tr>
<td>${d[0]}</td>
<td>${d[1]}</td>
<td>${d[2]}</td>
<td>${d[3]}</td>
<td><a href="/scan/${d[2]}" class="btn">Scan</a></td>
</tr>
`;

});

// SEARCH FILTER
let search = document.getElementById("searchBox");
if(search){
search.addEventListener("keyup", function(){

let value = this.value.toLowerCase();
let rows = table.getElementsByTagName("tr");

for(let i=0;i<rows.length;i++){
let text = rows[i].innerText.toLowerCase();
rows[i].style.display = text.includes(value) ? "" : "none";
}

});
}

});
}